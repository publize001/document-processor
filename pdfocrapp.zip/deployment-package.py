# application.py
from flask import Flask, render_template, request, send_file
import requests
import os
import time
from urllib.parse import urljoin

# Initialize Flask application
application = Flask(__name__)
app = application

# ABBYY credentials are now hardcoded for this example
# In production, use AWS Parameter Store or Environment Variables
ABBYY_APPLICATION_ID = '377be54c-90a4-4753-aa87-95d107591d45'
ABBYY_PASSWORD = 'OBRrA8TWH4yJv1wsrQBkt5z'
ABBYY_BASE_URL = 'https://cloud.ocrsdk.com'

# Configure upload folder
UPLOAD_FOLDER = '/tmp/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def process_pdf_with_abbyy(file_path):
    """Process PDF file with ABBYY Cloud OCR SDK"""
    # Upload file
    with open(file_path, 'rb') as file:
        upload_url = urljoin(ABBYY_BASE_URL, 'processDocument')
        response = requests.post(
            upload_url,
            auth=(ABBYY_APPLICATION_ID, ABBYY_PASSWORD),
            files={'file': file},
            params={
                'language': 'English',
                'exportFormat': 'docx',
            }
        )
        if response.status_code != 200:
            raise Exception(f"Upload failed: {response.text}")
        task_id = response.json()['taskId']
    
    # Wait for processing to complete
    while True:
        status_url = urljoin(ABBYY_BASE_URL, f'getTaskStatus?taskId={task_id}')
        status = requests.get(
            status_url,
            auth=(ABBYY_APPLICATION_ID, ABBYY_PASSWORD)
        ).json()
        
        if status['status'] == 'Completed':
            return status['resultUrl']
        elif status['status'] == 'Error':
            raise Exception("OCR processing failed")
        
        time.sleep(5)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded', 400
    
    file = request.files['file']
    if file.filename == '':
        return 'No file selected', 400
    
    if not file.filename.lower().endswith('.pdf'):
        return 'Please upload a PDF file', 400
    
    # Save uploaded file
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)
    
    try:
        # Process with ABBYY
        result_url = process_pdf_with_abbyy(file_path)
        
        # Download result
        response = requests.get(result_url)
        output_path = os.path.join(UPLOAD_FOLDER, 
                                 file.filename.replace('.pdf', '.docx'))
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return send_file(output_path, as_attachment=True)
    
    except Exception as e:
        return str(e), 500
    
    finally:
        # Cleanup
        if os.path.exists(file_path):
            os.remove(file_path)

if __name__ == '__main__':
    application.run()
